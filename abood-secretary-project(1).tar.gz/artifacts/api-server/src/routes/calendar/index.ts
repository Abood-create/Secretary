import { Router } from "express";
import { CheckCalendarConflictsBody, CreateCalendarEventBody } from "@workspace/api-zod";
import { listCalendarEvents, createCalendarEvent } from "../../lib/googleCalendar.js";

const router = Router();

router.post("/events/check", async (req, res) => {
  const parsed = CheckCalendarConflictsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { startTime, endTime } = parsed.data;

  try {
    const items = await listCalendarEvents({
      timeMin: startTime.toISOString(),
      timeMax: endTime.toISOString(),
      singleEvents: true,
      orderBy: "startTime",
    });

    const conflicts = (items ?? []).filter((e) => {
      const eStart = new Date(e.start?.dateTime ?? e.start?.date ?? "");
      const eEnd = new Date(e.end?.dateTime ?? e.end?.date ?? "");
      return eStart < endTime && eEnd > startTime;
    }).map((e) => ({
      id: e.id ?? "",
      title: e.summary ?? "Untitled",
      start: new Date(e.start?.dateTime ?? e.start?.date ?? "").toISOString(),
      end: new Date(e.end?.dateTime ?? e.end?.date ?? "").toISOString(),
    }));

    res.json({ hasConflicts: conflicts.length > 0, conflicts });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Calendar error";
    res.status(503).json({ error: msg });
  }
});

router.post("/events", async (req, res) => {
  const parsed = CreateCalendarEventBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { title, startTime, endTime, description } = parsed.data;

  try {
    const event = await createCalendarEvent({
      summary: title,
      description: description ?? undefined,
      start: {
        dateTime: startTime.toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      end: {
        dateTime: endTime.toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
    });

    res.status(201).json({
      id: event.id ?? "",
      title: event.summary ?? title,
      start: event.start?.dateTime ?? startTime.toISOString(),
      end: event.end?.dateTime ?? endTime.toISOString(),
      description: event.description ?? undefined,
      htmlLink: event.htmlLink ?? undefined,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Calendar error";
    res.status(503).json({ error: msg });
  }
});

export default router;
