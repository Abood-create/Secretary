import { Router, type IRouter } from "express";
import healthRouter from "./health";
import openaiRouter from "./openai/index.js";
import calendarRouter from "./calendar/index.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/openai", openaiRouter);
router.use("/calendar", calendarRouter);

export default router;
